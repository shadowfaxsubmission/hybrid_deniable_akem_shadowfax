
# Performance

```
nike_keygen cycles: 208034
nike_sdk cycles: 210053
nike_akem_encap cycles: 629079
nike_akem_decap cycles: 418816
```

